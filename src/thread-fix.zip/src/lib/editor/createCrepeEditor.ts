import { Crepe, CrepeFeature } from '@milkdown/crepe';
import { listener, listenerCtx } from '@milkdown/plugin-listener';
import { replaceAll, getMarkdown } from '@milkdown/utils';
import {
  preprocessThreadsForEditor,
  postprocessThreadsForStorage,
} from './preprocessing/threadPreprocessor';

// Import Crepe base styles
import '@milkdown/crepe/theme/common/style.css';
// Our custom theme overrides Crepe defaults
import '../../styles/crepe-anvil.css';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface CrepeEditorConfig {
  root: HTMLElement;
  defaultValue: string;
  onChange: (markdown: string) => void;
  nodeViewFactory?: any;
  mode: 'edit' | 'view' | 'source';
  placeholder?: string;
}

export interface CrepeEditorInstance {
  crepe: Crepe;
  destroy: () => void;
  replaceContent: (markdown: string) => void;
  appendContent: (markdown: string) => void;
  getMarkdown: () => string;
  getRawMarkdown: () => string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Editor Factory
// ─────────────────────────────────────────────────────────────────────────────

export async function createCrepeEditor(
  config: CrepeEditorConfig
): Promise<CrepeEditorInstance> {
  const {
    root,
    defaultValue,
    onChange,
    mode,
    placeholder = 'Start writing, or type / for commands...',
  } = config;

  const isEditable = mode === 'edit';
  const isSourceMode = mode === 'source';

  // ─────────────────────────────────────────────────────────────────────────
  // CRITICAL: Preprocess ::: thread → HTML div for rendering
  // ─────────────────────────────────────────────────────────────────────────

  const processedDefaultValue = isSourceMode
    ? defaultValue
    : preprocessThreadsForEditor(defaultValue);

  console.log('[Crepe] Mode:', mode);
  console.log('[Crepe] Preprocessing applied:', !isSourceMode);
  if (!isSourceMode && defaultValue !== processedDefaultValue) {
    console.log('[Crepe] Threads were preprocessed for editor');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Create Crepe Instance
  // ─────────────────────────────────────────────────────────────────────────

  const crepe = new Crepe({
    root,
    defaultValue: processedDefaultValue,
    features: {
      [CrepeFeature.BlockEdit]: isEditable,
      [CrepeFeature.Toolbar]: isEditable,
      [CrepeFeature.LinkTooltip]: true,
      [CrepeFeature.ListItem]: true,
      [CrepeFeature.Table]: true,
      [CrepeFeature.Cursor]: true,
      [CrepeFeature.ImageBlock]: isEditable,
      [CrepeFeature.Placeholder]: isEditable,
      [CrepeFeature.CodeMirror]: false,
      [CrepeFeature.Latex]: false,
    },
    featureConfigs: {
      [CrepeFeature.Placeholder]: {
        text: placeholder,
      },
      [CrepeFeature.LinkTooltip]: {
        onCopyLink: () => {
          console.log('Link copied to clipboard');
        },
      },
    },
  });

  // ─────────────────────────────────────────────────────────────────────────
  // Add Listener Plugin for Change Events
  // ─────────────────────────────────────────────────────────────────────────

  crepe.editor.use(listener);

  crepe.editor.config((ctx) => {
    const listenerInstance = ctx.get(listenerCtx);

    listenerInstance.markdownUpdated((_ctx, markdown, prevMarkdown) => {
      if (markdown !== prevMarkdown) {
        // CRITICAL: Postprocess HTML → ::: thread for storage
        const storageMarkdown = isSourceMode
          ? markdown
          : postprocessThreadsForStorage(markdown);

        onChange(storageMarkdown);
      }
    });
  });

  // ─────────────────────────────────────────────────────────────────────────
  // Create the Editor
  // ─────────────────────────────────────────────────────────────────────────

  await crepe.create();

  // ─────────────────────────────────────────────────────────────────────────
  // Return Instance with Helper Methods
  // ─────────────────────────────────────────────────────────────────────────

  return {
    crepe,

    destroy: () => {
      crepe.destroy();
    },

    replaceContent: (markdown: string) => {
      // Preprocess before inserting into editor
      const processed = isSourceMode
        ? markdown
        : preprocessThreadsForEditor(markdown);
      crepe.editor.action(replaceAll(processed));
    },

    appendContent: (markdown: string) => {
      // Get current content (in editor format with HTML)
      const current = crepe.editor.action(getMarkdown());
      const spacing = current.endsWith('\n\n') ? '' : current.endsWith('\n') ? '\n' : '\n\n';

      // Preprocess the new content
      const processedNew = isSourceMode
        ? markdown
        : preprocessThreadsForEditor(markdown);

      const combined = current + spacing + processedNew;
      crepe.editor.action(replaceAll(combined));
    },

    getMarkdown: () => {
      // Return storage-ready markdown (with ::: syntax)
      const raw = crepe.editor.action(getMarkdown());
      return isSourceMode ? raw : postprocessThreadsForStorage(raw);
    },

    getRawMarkdown: () => {
      // Return exactly what's in the editor (with HTML)
      return crepe.editor.action(getMarkdown());
    },
  };
}
