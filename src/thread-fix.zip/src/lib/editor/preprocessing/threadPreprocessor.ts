// ─────────────────────────────────────────────────────────────────────────────
// Thread Preprocessor
//
// Converts ::: thread blocks to HTML divs for Milkdown rendering,
// and converts back to ::: syntax on save.
//
// EXPECTED INPUT FORMAT: ::: thread <type> id:<id> timestamp:<timestamp>
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Regex Patterns
// ─────────────────────────────────────────────────────────────────────────────

// Match: ::: thread <type> id:<id> timestamp:<timestamp>\n<content>\n:::
// Captures: [1]=type, [2]=id (optional), [3]=timestamp (optional), [4]=content
const THREAD_DIRECTIVE_REGEX = /::: thread (\w+)(?: id:(\S+))?(?: timestamp:([^\n]+))?\n([\s\S]*?)\n:::/g;

// Match HTML thread containers we created
const THREAD_HTML_REGEX = /<div class="thread-container thread-(\w+)" data-thread-id="([^"]*)" data-timestamp="([^"]*)">\n([\s\S]*?)\n<\/div>\n<!-- \/thread -->/g;

// ─────────────────────────────────────────────────────────────────────────────
// Preprocess: ::: thread → HTML div (for editor rendering)
// ─────────────────────────────────────────────────────────────────────────────

export function preprocessThreadsForEditor(markdown: string): string {
  // Reset regex state (global flag requires this)
  THREAD_DIRECTIVE_REGEX.lastIndex = 0;

  const result = markdown.replace(
    THREAD_DIRECTIVE_REGEX,
    (match, type, id = '', timestamp = '', content) => {
      const trimmedContent = content.trim();
      const safeId = id || '';
      const safeTimestamp = timestamp ? timestamp.trim() : '';

      console.log(`[Preprocessor] Converting thread: type=${type}, id=${safeId}`);

      return `<div class="thread-container thread-${type}" data-thread-id="${safeId}" data-timestamp="${safeTimestamp}">
${trimmedContent}
</div>
<!-- /thread -->`;
    }
  );

  return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Postprocess: HTML div → ::: thread (for storage)
// ─────────────────────────────────────────────────────────────────────────────

export function postprocessThreadsForStorage(markdown: string): string {
  // Reset regex state
  THREAD_HTML_REGEX.lastIndex = 0;

  const result = markdown.replace(
    THREAD_HTML_REGEX,
    (match, type, id, timestamp, content) => {
      let directive = `::: thread ${type}`;
      if (id) directive += ` id:${id}`;
      if (timestamp) directive += ` timestamp:${timestamp}`;

      const trimmedContent = content.trim();

      console.log(`[Postprocessor] Converting back: type=${type}, id=${id}`);

      return `${directive}\n${trimmedContent}\n:::`;
    }
  );

  return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Debug Helpers
// ─────────────────────────────────────────────────────────────────────────────

export function hasThreadDirectives(markdown: string): boolean {
  THREAD_DIRECTIVE_REGEX.lastIndex = 0;
  return THREAD_DIRECTIVE_REGEX.test(markdown);
}

export function hasThreadHtml(markdown: string): boolean {
  THREAD_HTML_REGEX.lastIndex = 0;
  return THREAD_HTML_REGEX.test(markdown);
}

export function countThreadDirectives(markdown: string): number {
  THREAD_DIRECTIVE_REGEX.lastIndex = 0;
  const matches = markdown.match(THREAD_DIRECTIVE_REGEX);
  return matches ? matches.length : 0;
}
