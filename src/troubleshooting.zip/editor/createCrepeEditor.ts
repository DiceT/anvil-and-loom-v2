import { Crepe, CrepeFeature } from '@milkdown/crepe';
import { listener, listenerCtx } from '@milkdown/plugin-listener';
import { replaceAll, getMarkdown } from '@milkdown/utils';
import { threadFeature } from './features/thread';

// Import Crepe base styles
import '@milkdown/crepe/theme/common/style.css';
// Our custom theme overrides Crepe defaults
import '../../styles/crepe-anvil.css';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface CrepeEditorConfig {
  root: HTMLElement;
  defaultValue: string;
  onChange: (markdown: string) => void;
  nodeViewFactory?: any;
  mode: 'edit' | 'view' | 'source';
  placeholder?: string;
}

export interface CrepeEditorInstance {
  crepe: Crepe;
  destroy: () => void;
  replaceContent: (markdown: string) => void;
  appendContent: (markdown: string) => void;
  getMarkdown: () => string;
  getRawMarkdown: () => string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Editor Factory
// ─────────────────────────────────────────────────────────────────────────────

export async function createCrepeEditor(
  config: CrepeEditorConfig
): Promise<CrepeEditorInstance> {
  const {
    root,
    defaultValue,
    onChange,
    mode,
    placeholder = 'Start writing, or type / for commands...',
  } = config;

  const isEditable = mode === 'edit';

  console.log('[Crepe] createCrepeEditor called. Mode:', mode);

  // ─────────────────────────────────────────────────────────────────────────
  // Create Crepe Instance
  // ─────────────────────────────────────────────────────────────────────────

  const crepe = new Crepe({
    root,
    defaultValue: defaultValue, // Pass markdown directly, no preprocessor!
    features: {
      [CrepeFeature.BlockEdit]: isEditable,
      [CrepeFeature.Toolbar]: isEditable,
      [CrepeFeature.LinkTooltip]: isEditable, // Disable in view mode
      [CrepeFeature.ListItem]: true,
      [CrepeFeature.Table]: true,
      [CrepeFeature.Cursor]: isEditable,
      [CrepeFeature.ImageBlock]: isEditable,
      [CrepeFeature.Placeholder]: isEditable,
      [CrepeFeature.CodeMirror]: false,
      [CrepeFeature.Latex]: false,
    },
    featureConfigs: {
      [CrepeFeature.Placeholder]: {
        text: placeholder,
      },
    },
  });

  // ─────────────────────────────────────────────────────────────────────────
  // Configure Features & Plugins
  // ─────────────────────────────────────────────────────────────────────────

  // 1. Thread Feature (NATIVE!)
  crepe.editor.use(threadFeature);

  // 2. Change Listener (Only in Edit Mode)
  if (isEditable) {
    crepe.editor.use(listener);

    crepe.editor.config((ctx) => {
      const listenerInstance = ctx.get(listenerCtx);
      listenerInstance.markdownUpdated((_ctx, markdown, prevMarkdown) => {
        if (markdown !== prevMarkdown) {
          onChange(markdown);
        }
      });
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Create the Editor
  // ─────────────────────────────────────────────────────────────────────────

  await crepe.create();

  // ─────────────────────────────────────────────────────────────────────────
  // Return Instance with Helper Methods
  // ─────────────────────────────────────────────────────────────────────────

  return {
    crepe,

    destroy: () => {
      crepe.destroy();
    },

    replaceContent: (markdown: string) => {
      crepe.editor.action(replaceAll(markdown));
    },

    appendContent: (markdown: string) => {
      const current = crepe.editor.action(getMarkdown());
      const spacing = current.endsWith('\n\n') ? '' : current.endsWith('\n') ? '\n' : '\n\n';
      const combined = current + spacing + markdown;
      crepe.editor.action(replaceAll(combined));
    },

    getMarkdown: () => {
      return crepe.editor.action(getMarkdown());
    },

    getRawMarkdown: () => {
      return crepe.editor.action(getMarkdown());
    },
  };
}
